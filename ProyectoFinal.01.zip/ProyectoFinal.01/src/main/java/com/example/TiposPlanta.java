package com.example;

public class TiposPlanta {
    private String nombre;
    private String tipo;

    public TiposPlanta(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }
}
