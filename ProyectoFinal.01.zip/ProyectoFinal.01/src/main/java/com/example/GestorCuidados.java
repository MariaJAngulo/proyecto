package com.example;

import java.util.List;

public class GestorCuidados {
    private String area;
    private String fechaHora;
    private List<TiposPlanta> plantas;
    private List<Botanico> botanicos;
    private String resultado;
    private String estado;

    public GestorCuidados(String area, String fechaHora, List<TiposPlanta> plantas, List<Botanico> botanicos) {
        this.area = area;
        this.fechaHora = fechaHora;
        this.plantas = plantas;
        this.botanicos = botanicos;
        this.estado = "PENDIENTE";
    }

    public String getArea() {
        return area;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public List<TiposPlanta> getPlantas() {
        return plantas;
    }

    public List<Botanico> getBotanicos() {
        return botanicos;
    }

    public String getResultado() {
        return resultado;
    }

    public String getEstado() {
        return estado;
    }

    public void iniciarCuidado() {
        estado = "EN PROCESO";
    }

    public void finalizarCuidado(String resultado) {
        estado = "FINALIZADO";
        this.resultado = resultado;
    }

    public void aplazarCuidado() {
        estado = "APLAZADO";
    }

    public void Area(String resultadoArea) {
    }
}