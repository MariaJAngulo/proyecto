package com.example;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BotanicoTest {
    

    @Test
    public void testGetNumeroCelular() {
        String numeroEsperado="310541926";
        Botanico numeroCelular= new Botanico(0, numeroEsperado, numeroEsperado, numeroEsperado, numeroEsperado);
        numeroCelular.setNumeroCelular(numeroEsperado);
        assertEquals(numeroEsperado, numeroCelular.getNumeroCelular());
    }

    

    @Test
    public void testSetEmail() {
        String resultadoemail="example.com";
        Botanico email=new Botanico(0,"example", resultadoemail, resultadoemail, resultadoemail);
        email.setEmail(resultadoemail);
        assertEquals(resultadoemail, email.getEmail());

    }

    
}
